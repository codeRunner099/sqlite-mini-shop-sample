const { createApp, ref, computed } = Vue;

const app = createApp({
setup() {
const products = ref([]);
const cart = ref([]);
const searchQuery = ref("");
const selectedCategory = ref("");
const quantitySelection = ref({});
const checkoutBusy = ref(false);
const checkoutMessage = ref("");

const categories = computed(() => {
const set = new Set();
products.value.forEach(product => {
if (product.category) {
set.add(product.category);
}
});
return Array.from(set).sort();
});

const filteredProducts = computed(() => {
const query = searchQuery.value.toLowerCase().trim();
const category = selectedCategory.value;
return products.value.filter(product => {
if (category && product.category !== category) {
return false;
}
if (!query) {
return true;
}
const values = [product.name, product.description, product.category].filter(Boolean).map(value => value.toLowerCase());
return values.some(value => value.includes(query));
});
});

const cartItems = computed(() => {
return cart.value.map(entry => {
return {
product: entry.product,
quantity: entry.quantity
};
});
});

const subtotal = computed(() => {
return cart.value.reduce((sum, entry) => {
return sum + entry.product.price * entry.quantity;
}, 0);
});

const taxAmount = computed(() => {
return subtotal.value * 0.19;
});

const total = computed(() => {
return subtotal.value + taxAmount.value;
});

function loadInitialProducts() {
fetch("/api/products")
.then(response => response.json())
.then(data => {
products.value = data;
const next = {};
data.forEach(product => {
next[product.id] = 1;
});
quantitySelection.value = next;
})
.catch(() => {
products.value = [];
quantitySelection.value = {};
});
}

function reloadProducts() {
loadInitialProducts();
}

function addToCart(product) {
const quantity = quantitySelection.value[product.id] || 1;
if (!Number.isFinite(quantity) || quantity <= 0) {
return;
}
if (product.stock <= 0) {
return;
}
const existing = cart.value.find(entry => entry.product.id === product.id);
if (existing) {
const newQuantity = existing.quantity + quantity;
if (newQuantity > product.stock) {
existing.quantity = product.stock;
} else {
existing.quantity = newQuantity;
}
} else {
const safeQuantity = quantity > product.stock ? product.stock : quantity;
cart.value.push({
product,
quantity: safeQuantity
});
}
}

function increaseCart(product) {
const entry = cart.value.find(item => item.product.id === product.id);
if (!entry) {
return;
}
if (entry.quantity < product.stock) {
entry.quantity += 1;
}
}

function decreaseCart(product) {
const entry = cart.value.find(item => item.product.id === product.id);
if (!entry) {
return;
}
if (entry.quantity > 1) {
entry.quantity -= 1;
} else {
cart.value = cart.value.filter(item => item.product.id !== product.id);
}
}

function removeFromCart(product) {
cart.value = cart.value.filter(item => item.product.id !== product.id);
}

function checkout() {
if (cart.value.length === 0) {
return;
}
checkoutBusy.value = true;
checkoutMessage.value = "";
const payload = {
items: cart.value.map(entry => {
return {
productId: entry.product.id,
quantity: entry.quantity
};
})
};
fetch("/api/orders", {
method: "POST",
headers: {
"Content-Type": "application/json"
},
body: JSON.stringify(payload)
})
.then(response => response.json())
.then(data => {
checkoutMessage.value = "Bestellung " + data.orderNumber + " wurde gespeichert.";
cart.value = [];
})
.catch(() => {
checkoutMessage.value = "Fehler beim Speichern der Bestellung.";
})
.finally(() => {
checkoutBusy.value = false;
});
}

loadInitialProducts();

return {
products,
cart,
searchQuery,
selectedCategory,
quantitySelection,
categories,
filteredProducts,
cartItems,
subtotal,
taxAmount,
total,
checkoutBusy,
checkoutMessage,
reloadProducts,
addToCart,
increaseCart,
decreaseCart,
removeFromCart,
checkout
};
}
});

app.mount("#app");
