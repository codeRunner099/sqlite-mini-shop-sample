const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();

const dbPath = path.join(__dirname, "shop.db");
const db = new sqlite3.Database(dbPath);

function initDatabase() {
db.serialize(() => {
db.run(
"CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT, description TEXT, price REAL NOT NULL, stock INTEGER NOT NULL)"
);
db.run(
"CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, items_json TEXT NOT NULL, total_price REAL NOT NULL)"
);
db.get(
"SELECT COUNT(*) AS count FROM products",
[],
(err, row) => {
const count = err || !row ? 0 : row.count;
if (count === 0) {
const stmt = db.prepare("INSERT INTO products (name, category, description, price, stock) VALUES (?, ?, ?, ?, ?)");
const values = [
["USB-C Netzteil 65W", "Elektronik", "Schnelles USB-C Netzteil mit 65 Watt Leistung für Laptop oder Smartphone.", 34.9, 20],
["Kabellose Maus", "Peripherie", "Ergonomische Funkmaus mit einstellbarer DPI und leisen Tasten.", 19.9, 35],
["Mechanische Tastatur", "Peripherie", "Mechanische Tastatur mit blauem Switch und Hintergrundbeleuchtung.", 79.9, 15],
["27 Zoll Monitor", "Displays", "27 Zoll Full-HD Monitor mit IPS-Panel und höhenverstellbarem Standfuß.", 189.0, 10],
["Externe SSD 1 TB", "Speicher", "1 TB USB-C SSD mit hoher Übertragungsgeschwindigkeit.", 129.0, 25]
];
values.forEach(v => {
stmt.run(v[0], v[1], v[2], v[3], v[4]);
});
stmt.finalize();
}
}
);
});
}

app.use(express.json());

app.get("/api/products", (req, res) => {
db.all(
"SELECT id, name, category, description, price, stock FROM products ORDER BY id",
[],
(err, rows) => {
if (err) {
res.status(500).json({ error: "Datenbankfehler" });
return;
}
res.json(rows);
}
);
});

app.post("/api/orders", (req, res) => {
const items = Array.isArray(req.body.items) ? req.body.items : [];
if (items.length === 0) {
res.status(400).json({ error: "Keine Positionen" });
return;
}
const ids = items.map(item => item.productId);
if (ids.length === 0) {
res.status(400).json({ error: "Keine Positionen" });
return;
}
const placeholders = ids.map(() => "?").join(",");
db.all(
"SELECT id, price FROM products WHERE id IN (" + placeholders + ")",
ids,
(err, rows) => {
if (err) {
res.status(500).json({ error: "Datenbankfehler" });
return;
}
let total = 0;
items.forEach(item => {
const row = rows.find(r => r.id === item.productId);
if (row) {
const quantity = item.quantity && item.quantity > 0 ? item.quantity : 0;
total += row.price * quantity;
}
});
db.run(
"INSERT INTO orders (items_json, total_price) VALUES (?, ?)",
[JSON.stringify(items), total],
function(insertErr) {
if (insertErr) {
res.status(500).json({ error: "Datenbankfehler" });
return;
}
const orderNumber = "SQ" + this.lastID;
res.json({ orderNumber });
}
);
}
);
});

app.use(express.static(path.join(__dirname, "public")));

const port = process.env.PORT || 3000;

initDatabase();

app.listen(port, () => {});
