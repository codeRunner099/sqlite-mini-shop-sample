SQLite Mini Shop
A small mini shop demo with a Vue.js frontend and a Node.js (Express) REST API using a local SQLite database, storing realistic sample products like chargers, mice, keyboards and SSDs. To start: open a terminal in the project folder, then run npm install, npm start, and open http://localhost:3000 in your browser.

SQLite Mini Shop
Ein kleiner Mini-Shop mit einem Vue.js Frontend und einer Node.js (Express) REST API auf Basis einer lokalen SQLite-Datenbank, mit realistischen Beispielprodukten wie Netzteilen, Mäusen, Tastaturen und SSDs. Zum Starten: Terminal im Projektordner öffnen, dann npm install, npm start ausführen und http://localhost:3000 im Browser öffnen.
